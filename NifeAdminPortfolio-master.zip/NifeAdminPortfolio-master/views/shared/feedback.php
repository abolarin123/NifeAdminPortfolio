<?php 
//session_start();
if(isset($_SESSION['success'])){
    ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
                               <h5 >   <i class="fa fa-check me-2"></i> Great! </h5>
                                <?php 
                               echo $_SESSION['success'] ; ?> 
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>

                                                                                            
    <?php
    unset($_SESSION['success']);
}
?>
<?php
if(isset($_SESSION['error'])){
    ?>
<div class="alert alert-danger alert-dismissible fade show" role="alert">
                                 <h5><i class="fa fa-exclamation-circle me-2"></i> Oops! Something went wrong </h5>
                                <?php 
                               echo $_SESSION['error'] ; ?> 
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>


    <?php
    unset($_SESSION['error']);

}

?>
<?php
if(isset($_SESSION['errors'])){
    ?>
<div class="alert alert-danger alert-dismissible fade show" role="alert">
                                 <h5><i class="fa fa-exclamation-circle me-2"></i> Oops! Something went wrong </h5>
                                 <ul>  <?php 
                                 foreach ($_SESSION ['errors'] as $key => $error) {
                                    # code...
                                    echo "<li>" .$error."</li>";
                                 }
                              ?> </ul>
                              
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>


    <?php
    unset($_SESSION['errors']);

}

?>
<?php
if(isset($_SESSION['msg'])){
    ?>
<div class="alert alert-info alert-dismissible fade show" role="alert">
                               <h5>   <i class="fa fa-exclamation-circle me-2"></i> Alert! </h5>
                                <?php 
                               echo $_SESSION['msg'] ; ?> 
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>


    <?php
    unset($_SESSION['msg']);
}
?>
<?php
//if() 
?>